module.exports.noReplay = {
    host     : 'mail.thinkmobiles.com',
    port     : 587,
    ignoreTLS: false,
    auth     : {
        user: 'no-replay@easyerp.com',
        pass: '111111'
    },
    tls      : {rejectUnauthorized: false}
};

module.exports.registerNewUserSaaS = {
    name : 'Andrew V',
    job  : 'Product Manager',
    phone: '(347) 391-8953',
    email: 'andrew.valenko@thinkmobiles.com',
    skype: 'andrew.valenko'
};

module.exports.registerNewUser = {
    name : 'Vasiliy Almashiy',
    job  : ' Business development manager',
    phone: '+380502215999',
    email: 'vasiliy.almashiy@thinkmobiles.com',
    skype: 'almashij'
};
