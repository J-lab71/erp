process.env.HOST = 'http://localhost:8089/';
process.env.TRACKER_HOST = 'http://localhost:8088';
process.env.MAIN_DB_HOST = 'localhost';
process.env.MAIN_DB_NAME = 'mainDB';
process.env.DB_PORT = 27017;
process.env.DB_USER = 'admin';
process.env.DB_PASS = '1q2w3e!@#';
process.env.OXR_APP_ID = '451784939cd549259b92764b7c4eced3';

process.env.SERVER_TYPE = 'openSource';
process.env.SERVER_PLATFORM = 'openSource';
process.env.SOCKET_DB_PORT = 6379;
process.env.SOCKET_DB_HOST = 'localhost';
process.env.SOCKET_DB = 9;

process.env.RABBITMQ_HOST = 'localhost';
process.env.RABBITMQ_PORT = 5672;
process.env.RABBITMQ_USER = 'easyErp';
process.env.RABBITMQ_PASSWORD = '111111';