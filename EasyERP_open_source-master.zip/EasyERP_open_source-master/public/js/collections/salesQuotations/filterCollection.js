﻿define([
    'collections/Quotations/filterCollection'
], function (filterCollection) {
    'use strict';

    return filterCollection;
});