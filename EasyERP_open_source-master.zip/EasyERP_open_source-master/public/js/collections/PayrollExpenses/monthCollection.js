/**
 * Created by lilya on 16/11/15.
 */
define([
    'Backbone'
], function (Backbone) {
    'use strict';

    var PayRollCollection = Backbone.Collection.extend({});

    return PayRollCollection;
});