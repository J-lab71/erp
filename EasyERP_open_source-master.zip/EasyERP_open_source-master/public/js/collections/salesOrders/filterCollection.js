﻿define([
    'collections/Orders/filterCollection'
], function (ParentCollection) {
    'use strict';

    return ParentCollection;

});
