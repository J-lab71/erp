﻿define([
    'collections/Invoices/filterCollection'
], function (filterCollection) {
    'use strict';
    return filterCollection;
});