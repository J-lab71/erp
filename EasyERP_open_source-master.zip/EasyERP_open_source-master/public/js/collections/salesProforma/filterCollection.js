﻿define([
    'collections/Proforma/filterCollection'
], function (filterCollection) {
    return filterCollection;
});