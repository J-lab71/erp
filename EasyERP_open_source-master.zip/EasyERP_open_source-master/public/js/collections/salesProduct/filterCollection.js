﻿define([
        'collections/Products/filterCollection'
    ],
    function (filterCollection) {
        'use strict';

        return filterCollection;
    });