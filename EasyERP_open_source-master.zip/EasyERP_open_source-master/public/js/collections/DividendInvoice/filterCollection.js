﻿define([
    'collections/invoice/filterCollection'
], function (filterCollection) {
    return filterCollection;
});
