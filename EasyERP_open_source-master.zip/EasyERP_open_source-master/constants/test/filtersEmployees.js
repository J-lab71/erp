define([], function () {
    return {
        _id: null,

        name: [
            {
                _id : '57626b85d3c7dc0c7755dc38',
                name: 'test test'
            },
            {
                _id : '57611e9db9bd9aa43438ed57',
                name: 'dasdaa daadasdasasas'
            },
            {
                _id : '575fc0bb7330dff16a340390',
                name: 'Ihor Kalashniuk'
            }
        ],
        
        department: [
            {
                _id : '55b92ace21e4b7c40f000012',
                name: '.NET/WP'
            },
            {
                _id : '560c0b83a5d4a2e20ba5068c',
                name: 'Finance'
            },
            {
                _id : '56802ec21afe27f547b7ba53',
                name: 'PHP/WordPress'
            }
        ]
    };
});
