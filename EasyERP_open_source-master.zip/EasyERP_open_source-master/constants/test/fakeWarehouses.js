define([], function () {
    return {
        data: [
            {
                _id    : "57dfc6ea6066337b771e99e2",
                account: "5788b4be52adaf4c49e4b51c",
                name   : "Main Warehouse"
            },
            {
                _id    : "584eb03a26538bfd30c4b5c8",
                account: "565eb53a6aa50532e5df0bc8",
                name   : "Test Magento Warehouse"
            },
            {
                _id    : "58515fe72bb7bd0349cfc689",
                account: null,
                name   : "tessting"
            },
            {
                _id    : "5851621e7cb03908492739a0",
                account: null,
                name   : "fewfwefwe"
            },
            {
                _id    : "585257a5178348ac17302926",
                account: "565eb53a6aa50532e5df0bc9",
                name   : "wrg"
            }
        ]
    };
});