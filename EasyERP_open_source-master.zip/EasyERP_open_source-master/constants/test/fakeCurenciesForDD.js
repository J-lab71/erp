define([], function () {
    return {
        data: [
            {
                _id     : 'ANG',
                decPlace: 2,
                symbol  : '',
                name    : 'ANG- Netherlands Antillean Guilder'
            },
            {
                _id     : 'USD',
                decPlace: 2,
                symbol  : '',
                name    : 'USD- United States Dollar'
            }
        ]
    }
});