/**
 * Created by Roman on 27.05.2015.
 */
var tmDev = require('./tmDevelopment');

module.exports = {
    tmDevelopment: tmDev
};