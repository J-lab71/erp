import React from "react"
import SEO from "../components/seo"
import logo from "../images/logo.png"

import Layout from "../components/Layout"

//TODO: Custom maken, columns is hier niet heel geschikt voor.

const JobListSuccesPage = () => (
  <Layout>
    <SEO title="Kluslijst succesvol aangemeld" />
    <div className="section section--success">
        <div className="container">
          <div className="columns is-vcentered section--success__columns">
            <div className="column">
              <div className="columns">
                <div className="column is-narrow">
                  <img className="is-invisible-mobile" src={logo} alt="tjilp-logo" width="80"/>
                </div>
                  <div className="column">
                    <h1 className="is-size-1 is-size-2-mobile has-text-primary">Je kluslijst is succesvol opgeslagen
                    </h1>
                </div>
              </div>
              <p>Zodra we iemand hebben gevonden die een aantal van je klusjes kan oplossen stellen we hem per e-mail aan je voor. Jij beslist zelf of je voor deze klusser kiest.</p>
            </div>
          </div>
        </div>
    </div>
  </Layout>
)

export default JobListSuccesPage
