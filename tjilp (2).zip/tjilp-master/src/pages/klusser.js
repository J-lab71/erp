import React from "react"
import SEO from "../components/seo"
import Layout from "../components/Layout"
import BecomeATjilperBanner from "../components/BecomeATjilperBanner"
import HowItWorks from "../components/HowItWorks/HowItWorks"
import TabItemsKlusser from "../components/HowItWorks/TabItemsKlusser"


const IndexPage = () => (
  <Layout>
    <SEO title="Ik ben klusser" />
    <BecomeATjilperBanner />
    <HowItWorks tabItems={TabItemsKlusser} />
  </Layout>
)

export default IndexPage
