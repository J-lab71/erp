import React from "react"
import SEO from "../components/seo"
import Layout from "../components/Layout"
import voorwaarden from "../files/algemenevoorwaarden.pdf"
import bemiddeling from "../files/bemiddelingsovereenkomst.pdf"


const Voorwaarden = () => (
  <Layout>
    <SEO title="Voorwaarden" />
    <div className="section">
        <div className="container">
            <h1 className="is-size-1">Algemene voorwaarden en bemiddelingsovereenkomst</h1>
            Op deze pagina vind je de laatste versie van onze algemene voorwaarden en bemiddelingsovereenkomst.
            <br/><br/>
            <h3 className="is-size-4">Algemene voorwaarden:</h3>
            <p>Download <a href={voorwaarden} target="_blank" rel="noopener noreferrer">algemene voorwaarden</a></p>
            <br/>
            <h3 className="is-size-4">Bemiddelingsovereenkomst:</h3>
            <p>Download <a href={bemiddeling} target="_blank" rel="noopener noreferrer">bemiddelingsovereenkomst</a></p>

        </div>
    </div>
  </Layout>
)

export default Voorwaarden
