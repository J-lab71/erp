import React from "react"
import SEO from "../components/seo"

import Layout from "../components/Layout"

import PlaceJobBanner from "../components/PlaceJobBanner"
import HowItWorks from "../components/HowItWorks/HowItWorks"
import TabItems from "../components/HowItWorks/TabItems"

const IndexPage = () => (
  <Layout>
    <SEO title="Tjilp" />
    <PlaceJobBanner />
    <HowItWorks tabItems={TabItems}/>
  </Layout>
)

export default IndexPage
