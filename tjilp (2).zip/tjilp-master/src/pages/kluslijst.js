import React from "react"
import Layout from "../components/Layout"
import SEO from "../components/seo"
import { faTimesCircle, faPlusCircle } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import Checkbox from "../components/Checkbox"

const exampleJobs = [
  {
    title:"Ikea kast in elkaar zetten",
    analytics:"ikea-kast",
    price:44
  },
  {
    title:"Lamp ophangen",
    analytics:"lamp-ophangen",
    price:22
  },
  {
    title:"Grof vuil wegbrengen",
    analytics:"grofvuil",
    price:35
  },
  {
    title:"Muurtje schilderen",
    analytics:"trap-schilderen",
    price:57
  },
  {
    title:"Heg snoeien",
    analytics:"heg-snoeien",
    price:35
  },
  {
    title:"Helpen met verhuizen",
    analytics:"verhuizen",
    price:70
  },
  {
    title:"laminaat leggen",
    analytics:"laminaat",
    price:132
  },
  {
    title:"Schilderij ophangen",
    analytics:"schilderij-ophangen",
    price:17
  },
  {
    title:"Zware spullen verplaatsen",
    analytics:"zware-spullen-verplaatsen",
    price:44
  },
  {
    title:"Regenpijp vastzetten",
    analytics:"regenpijp-vastzetten",
    price:22
  },
  {
    title:"Dakgoot schoonmaken",
    analytics:"dakgoot-schoonmaken",
    price:22
  },
  {
    title:"Grasmaaien",
    analytics:"grasmaaien",
    price:22
  },
  {
    title:"TV ophangen",
    analytics:"tv-ophangen",
    price:44
  },
]

class KlusLijst extends React.Component{
  constructor(props){
    super(props)
    this.state = {
      jobListNotice:""
    }
  }

  changeNotice = (notice) => {
    this.setState({jobListNotice:notice})
  }

  render(){
    return(
      <Layout nav="white">
      <SEO title="Jouw tjilp kluslijst" />
      <div className="section">
        <div className="container">
          <h1 className="is-size-2 has-text-primary">Maak je kluslijstje aan</h1>
            <div className={`job-list__notice ${this.state.jobListNotice!=="" ? "" : "job-list__notice--is-hidden"}`}>
              {this.state.jobListNotice}
          </div>
          <div className="columns">
            <div className="column is-half">
              <p className="is-size-5-desktop is-primary">Verzamel je kleine klusjes en wij stellen je vrijblijvend voor aan een handige klusser uit de buurt die ze al fluitend voor je kan oplossen tegen een scherp tarief!</p>      
            </div>
          </div>
        </div>
      </div>
      <KlusLijstController changeParentNotice={this.changeNotice}/>
    </Layout>
    )
  }
}

class KlusLijstController extends React.Component {
  
  constructor(props){
    super(props)
    let initialJoblist = []
    if(typeof window!=="undefined"){
      if(localStorage.getItem("jobList")){
        initialJoblist=JSON.parse(localStorage.getItem("jobList"));
      }
    }
    
    this.state = {
      jobList:initialJoblist,
      exampleJobList:exampleJobs,
      submitFormVisible:false,
    }
  }

  componentDidMount(){
    if(sessionStorage.getItem('first-job') && sessionStorage.getItem('first-job')!==""){
      let firstJob=sessionStorage.getItem('first-job');
      this.addJob(firstJob);
      sessionStorage.removeItem('first-job') //remove first job if it exists.
      this.props.changeParentNotice(`Je eerste klus (${firstJob}) is succesvol toegevoegd aan jouw kluslijst!`)
    }
  }

  addJob = (jobTitle, jobPrice) => {
    let job={jobTitle:jobTitle,jobPrice:jobPrice}
     this.setState(state => {
      const jobList = state.jobList.concat(job)
      return{
        jobList
      }
    }, 
      ()=>localStorage.setItem("jobList",JSON.stringify(this.state.jobList))
    )
  }

  getLocalStorageJobs = () => {
    return JSON.parse(localStorage.getItem('kluslijst'));
  }

  removeJob = (i) => {
    this.setState(state => {
      const jobList = state.jobList.filter((item, j) => i !== j )
      return {
        jobList
      }
    },
      ()=>localStorage.setItem("jobList",JSON.stringify(this.state.jobList))
    )
  }

  addExampleJob = (jobTitle, jobPrice, exampleKey) => {
    this.addJob(jobTitle, jobPrice);
    this.setState(state => {
      const exampleJobList = state.exampleJobList.filter((item, j) => exampleKey !== j)
      return{
        exampleJobList
      }
    })
  }

  toggleJobSubmitModal = () => {
    this.setState({
      submitFormVisible:!this.state.submitFormVisible
    })
  }

  render(){

    const jobList = this.state.jobList.map((job, index) =>
      <div key={index} className="panel-block job-list__item">
        <span className="job-list__item__title">{job.jobTitle}</span>
        <div className="job-list__item__right">
          {/* <span className="job-list__price">{job.jobPrice ? `€ ${job.jobPrice}` : ""}</span> */}
          <div className="job-list__delete" data-track-id="job-list__delete" data-track-data={job.jobTitle} onClick={() => this.removeJob(index)}><FontAwesomeIcon  icon={faTimesCircle} /></div>
        </div>
      </div>
    )
    const exampleJobList = this.state.exampleJobList;
    const examples = exampleJobList.map((example, index) =>
      <div key={index} className="column is-half">
        <div className="card card--job-examples has-light-grey-background" data-track-id={`example-job-${example.analytics}`} data-track-data={example.title} onClick={() => this.addExampleJob(example.title, example.price, index)}>
          <div className="card-content card-content__examples has-background-secondary-lighter">
            <h4 className="is-size-5">{example.title}</h4>
            <div className="card--job-examples__bottom">
              <span className="card--job-examples__price"><span className="has-text-weight-bold is-size-7">Indicatie</span> € {example.price} <br/><span className="is-size-7 is-italic">op basis van € 22 per uur</span></span>
              <FontAwesomeIcon className="is-size-3 has-text-secondary" icon={faPlusCircle} />
            </div>
          </div>
        </div>
      </div>
    )

    return(
      <div className="section job-list">
        <div className="container">
          <div className="columns">
            <div className="column">
              <h4 className="is-size-4">Mijn kluslijst</h4>
              <p>Voeg je klusjes toe of kies uit onze lijst van populaire klusjes.</p><br/>
              <div className="job-list__panel panel is-white">
                <div>
                  <p className="panel-heading">
                    Klusjes
                  </p>
                {jobList}
                </div>
                <div>
                  <div className="panel-block panel-block--bottom">           
                    <PlaceJobForm addJob={this.addJob} />
                    <SubmitForm jobs={this.state.jobList} visible={this.state.submitFormVisible} toggleVisibility={this.toggleJobSubmitModal}/>
                    <button className="job-list__submit button is-rounded is-success has-text-white" onClick={this.toggleJobSubmitModal} data-track-id="job-list-open-modal">Bewaar kluslijst</button>
                  </div>
                </div>
              </div>
            </div>

            <div className="column">
              <h4 className="is-size-4">Populaire klussen</h4>
              <p>Onderstaande prijsindicaties zijn op basis van een uurtarief van 22 per uur en een gemiddelde tijd. Dit kan variëren per klusser en klusje.</p><br/>
              <div className="columns is-multiline">
                {examples}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

class PlaceJobForm extends React.Component {
  state = {value:""}

  handleFormSubmit = (e) => {
    e.preventDefault();
    if(this.state.value!==""){
      this.props.addJob(this.state.value)
      this.setState({value:""})
    }
  }

  handleInputChange = (e) => {
    this.setState({value:e.target.value})
  }

  render(){
    return(
      <form className="place-job-form" data-track-id="place-job-form" onSubmit={this.handleFormSubmit}>
        <div className="field place-job-form__input">
          <div className="control">
            <input className="input is-primary" name="job-form-add" autoFocus onChange={this.handleInputChange} value={this.state.value} type="text" placeholder="Wat voor klusjes heb je nog liggen?" />
          </div>
        </div>
        <div className="field place-job-form__button-wrapper">
          <div className="place-job-form__button control">
            <button className="button is-rounded is-primary has-text-white has-text-weight-medium">Toevoegen</button>
          </div>
        </div>
      </form>
    )
  }
}


const SubmitForm = (props) => {
  let kluslijstInput = "";

  props.jobs.forEach(job => kluslijstInput+=`${job.jobTitle}, `);

  return(
    <div className={`modal ${props.visible ? "is-active" : ""}`}>
      <div className="modal-background"></div>
      <div className="modal-card">
        <header className="modal-card-head has-background-white">
          <p className="modal-card-title is-size-4 has-text-weight-bold has-text-primary">Update lijstje</p>
          <button className="delete" onClick={props.toggleVisibility} aria-label="close"></button>
        </header>
        <section className="modal-card-body">
          <p className="is-size-6 has-text-primary">Als je hieronder je postcode en e-mailadres invult, sturen wij jou een mailtje zodra we een handige klusser hebben gevonden! Jij kiest zelf of je op het aanbod in wilt gaan en zit nergens aan vast. Je kunt jouw lijstje altijd updaten en delen op deze pagina.</p>
            
          <form action="/kluslijst-aanmelden-succesvol" data-track-id="submit-joblist-form" className="joblist-form" name="joblist-form" method="post" data-netlify="true" data-netlify-honeypot="bot-field">
            <input type="hidden" name="form-name" value="joblist-form" />
            <p className="is-invisible">
                <label>Niet invullen als je een mens bent: <input name="bot-field" /></label>
            </p>
            <input className="is-invisible" type="hidden" name="joblist" value={kluslijstInput} />
            <div className="field">
                <label className="label">Wat zijn de 4 cijfers van je postcode?</label>
                <div className="control">
                    <input className="input" required type="text" name="postcode" placeholder="0000" pattern="[0-9]{4}"/>
                </div>
            </div>
            <div className="field">
                <label className="label">Wat is je e-mailadres?</label>
                <div className="control">
                    <input className="input" required name="email" type="email" />
                </div>
            </div>
            <Checkbox inverted required name="voorwaarden" label={<span>Ik ben 18 jaar of ouder en ga akkoord met de <a href="/voorwaarden" target="_blank">algemene voorwaarden</a> en <a href="/privacy" target="_blank">privacy</a> statement. </span>} /><br/>
            <button className="button is-success has-text-white is-rounded">Update kluslijst</button><br/><br/>
            <p className="is-italic is-size-7">Dit formulier wordt tegen spam beschermd met behulp van <a href="https://akismet.com/privacy/" target="_blank" rel="noopener noreferrer">Akismet</a></p>
          </form>
        </section>
      </div>
    </div>
  )
}


export default KlusLijst
