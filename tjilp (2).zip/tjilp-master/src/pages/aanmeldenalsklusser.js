import React from "react"
import Layout from "../components/Layout"
import SEO from "../components/seo"
import Checkbox from "../components/Checkbox"
import RangeSlider from "../components/RangeSlider"

const AanmeldenKlusser = () => (
  <Layout nav="white">
    <SEO title="Meld je aan als klusser" />
    <div className="section has-background-primary has-text-white">
      <div className="container">
        <h1 className="is-size-2">Hoi Klusser</h1>
        <p className="is-size-4">Twee rechterhanden? Een leuk bedrag bijverdienen? Meld je aan als klusser op ons platform en wij matchen jouw skills met kluslijstjes in jouw stad!</p>
      </div>
    </div>
    <div className="section has-background-primary">
        <div className="container">
            <SignupTjilperForm />
        </div>
    </div>
  </Layout>
)

const SignupTjilperForm = () => (
    <form action="/klusser-aanmelden-succesvol" class="signup-tjilper" name="signup-tjilper" method="post" data-netlify="true" data-netlify-honeypot="bot-field">
        <input type="hidden" name="form-name" value="signup-tjilper" />
        <p class="is-invisible">
            <label>Niet invullen als je een mens bent: <input name="bot-field" /></label>
        </p>
        <div className="columns">
            <div className="signup-tjilper__container column is-half is-offset-3">
                    <h2 className="is-size-3">1. <span className="is-size-4">Vertel ons wat jij kan</span></h2>
                    <h6 className="is-size-6">Ik kan:</h6>
                    <Checkbox inverted name="lamp ophangen" label="Een lamp ophangen" /><br/>   
                    <Checkbox inverted name="ikea kast" label="Een ikea kast in elkaar zetten" /><br/>            
                    <Checkbox inverted name="grof vuil" label="Grof vuil wegbrengen" /><br/>
                    <Checkbox inverted name="schilderen" label="Een Muurtje schilderen" /><br/>
                    <Checkbox inverted name="spullen de trap op tillen" label="Spullen de trap op tillen" /><br/>
                    <Checkbox inverted name="verhuizen" label="Helpen met verhuizen" /><br/>
                    <div className="field">
                        <label className="label">En verder kan ik:</label>
                        <div className="control">
                            <input className="input" name="verderkanik" type="text" />
                        </div>
                    </div>
                    <h6 className="is-size-6">Heb je al het gereedschap?</h6>
                    <Checkbox inverted name="gereedschap" label="ja ik heb al het gereedschap" /><br/>
                    <hr/>
                    <h2 className="is-size-3">2. <span className="is-size-4">Meld je aan</span></h2>
                    <div className="field">
                        <label className="label">Naam</label>
                        <div className="control">
                            <input className="input" required name="Naam" type="text" />
                        </div>
                    </div>

                    <div className="field">
                        <label className="label">Wat zijn de 4 cijfers van jouw postcode?</label>
                        <div className="control">
                            <input className="input" required type="text" name="postcode" placeholder="0000" pattern="[0-9]{4}"/>
                        </div>
                    </div>
                    <div className="field">
                        <label className="label">Maximale reisafstand in km</label>
                        <div className="control">
                            <RangeSlider minValue="1" required maxValue="15" default="5" after="km" name="kilometers"/>
                        </div>
                    </div>

                    <div className="field">
                        <label className="label">Uurprijs</label>
                        <div className="control">
                            <RangeSlider minValue="15" required maxValue="35" default="20" before="€" name="uurprijs"/>
                        </div>
                    </div>

                    <div className="field">
                        <label className="label">Emailadres</label>
                        <div className="control">
                            <input className="input" required name="email" type="email" />
                        </div>
                    </div><br/>
                    <Checkbox inverted required name="voorwaarden" label={<span>Ik ben 18 jaar of ouder en ga akkoord met de <a href="/voorwaarden" target="_blank">algemene voorwaarden</a> en <a href="/privacy" target="_blank">privacy</a> statement. </span>} /><br/>
                    <button className="button is-success has-text-white is-rounded">Meld mij aan</button><br/><br/>
                    <p className="is-italic is-size-7">Dit formulier wordt tegen spam beschermd met behulp van <a href="https://akismet.com/privacy/" target="_blank" rel="noopener noreferrer">Akismet</a></p>
            </div>
        </div>
    </form>
)
export default AanmeldenKlusser


