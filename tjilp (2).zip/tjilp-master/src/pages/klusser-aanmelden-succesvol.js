import React from "react"
import SEO from "../components/seo"
import logo from "../images/logo.png"

import Layout from "../components/Layout"

//TODO: custom maken, columns is hier niet geschikt voor.

const TjilperSuccessPage = () => (
  <Layout>
    <SEO title="Succesvol aangemeld als klusser" />
    <div className="section section--success">
        <div className="container">
          <div className="columns is-vcentered section--success__columns">
            <div className="column">
              <div className="columns">
                <div className="column is-narrow">
                  <img className="is-invisible-mobile" src={logo} alt="tjilp-logo" width="80"/>
                </div>
                  <div className="column">
                    <h1 className="is-size-1 is-size-2-mobile has-text-primary">Je bent succesvol aangemeld</h1>
                </div>
              </div>
              <p>Wij gaan op zoek kluslijstjes die bij jou passen. Wanneer wij meer informatie over jou nodig hebben, nemen wij per e-mail contact met jou op.</p>
            </div>
          </div>
        </div>
    </div>
  </Layout>
)

export default TjilperSuccessPage
