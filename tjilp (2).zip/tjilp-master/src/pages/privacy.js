import React from "react"
import SEO from "../components/seo"
import Layout from "../components/Layout"
import { graphql } from "gatsby"

const Privacy = ({data}) => (
  <Layout>
    <SEO title="Privacy" />
    <div className="section section--markdown">
        <div className="container" dangerouslySetInnerHTML={{__html:data.markdownRemark.html}}>
            
        </div>
    </div>
  </Layout>
)

export default Privacy

export const query = graphql`
query MyQuery {
  markdownRemark(frontmatter: {page: {eq: "privacy"}}) {
    html
  }
}
`
