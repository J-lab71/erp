import React from "react"
import Img from "gatsby-image"
import {graphql, useStaticQuery} from "gatsby"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faList, faMapMarkerAlt, faThumbsUp, } from '@fortawesome/free-solid-svg-icons'
import { navigate } from "@reach/router"
import {Link}  from "gatsby"

const PlaceJobBanner = () => {

    const componentData = useStaticQuery(
        graphql`
            query {
                file(relativePath: {eq: "kluslijst-aanbieder.png"}) {
                    relativePath
                    childImageSharp {
                        fluid{
                            ...GatsbyImageSharpFluid
                        }
                    }
                  }
            }
        `
    )

    

    return(
        <>
        <div className="section has-background-primary">
            <div className="container has-text-white">
                <div className="place-job-column columns is-vcentered">
                    <div className="column is-half">
                        <h1 className="is-size-1">Al jouw kleine klusjes zo gepiept</h1>
                        <p>Plaats je kleine klusjes op je kluslijst en wij stellen je voor aan een handige klusser die ze al fluitend voor je oplost! Tegen een scherp tarief uiteraard. </p>
                        <PlaceJobBannerForm /> 
                        <div className="columns is-hidden-touch">
                            <div className="column">
                                <h3 className="is-size-3"><FontAwesomeIcon icon={faList}/></h3>
                                <p>1. Plaats je klusjes op je tjilp kluslijst</p>
                            </div>
                            <div className="column">
                            <h3 className="is-size-3"><FontAwesomeIcon icon={faMapMarkerAlt}/></h3>
                                <p>2. Wij stellen handige mensen voor bij jou uit de buurt</p>
                            </div>
                            <div className="column">
                            <h3 className="is-size-3"><FontAwesomeIcon icon={faThumbsUp}/></h3>
                                <p>3. Maak samen een afspraak</p>
                            </div>
                        </div>
                    </div>   
                    <div className="column is-offset-1 is-hidden-touch">
                        <Img fluid={componentData.file.childImageSharp.fluid} alt="kluslijst voorbeeld"/>
                    </div>       
                </div>
            </div>
        </div>
        </>
    )

}

class PlaceJobBannerForm extends React.Component{
    state = {klusje:""}

    handleInputChange = (e) => {
        this.setState({klusje:e.target.value})
    }

    handleFormSubmit = (e) => {
        e.preventDefault()
        sessionStorage.setItem('first-job',this.state.klusje)
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({'event':'first-job-click','first-job':this.state.klusje});
        navigate("/kluslijst/");
    }

    render(){
        return(
            <form className="place-job-banner-form" data-track-id="form-banner-klus-aanbieder" onSubmit={this.handleFormSubmit}>
                <div className="control place-job-banner-form__input">
                    <input className="input is-primary is-medium" type="text" autoFocus onChange={this.handleInputChange} name="klusplaatsen-home" placeholder="Wat voor klusje heb jij liggen?" value={this.state.klusje} />
                    <Link className="place-job-banner__popular has-text-success" data-track-id="popular-jobs-button" to="/kluslijst/">Of bekijk de 13 meest populaire klussen</Link>          
                </div>
                <div className="control place-job-banner-form__submit">
                    <button className="button is-rounded is-medium is-success has-text-white has-text-weight-medium">Plaats op je kluslijst</button>
                </div>
            </form>  
        )
    }
}

export default PlaceJobBanner
