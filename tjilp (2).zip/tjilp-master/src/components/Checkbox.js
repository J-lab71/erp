import React from "react"

const Checkbox = (props) => {
    return(
    <label className={`checkbox-container ${props.inverted ? "inverted" : ""}`}>
        <input className="checkbox" name={props.name} required={props.required ? true : false} type="checkbox"/>
        <span className="checkmark"></span>
        {props.label}
    </label>
    )
}
export default Checkbox
