import React from "react"
import {Link} from "gatsby"
import logo from "../images/logo.png"

const Footer = () => (
    <footer>
        <div className="section">
            <div className="container">
                <div className="columns">
                    <div className="column">
                        <div className="logo-container">
                            <img src={logo} alt="tjilp-logo"/>
                            <span className="has-text-weight-bold">Tjilp</span>
                        </div>
                        <p>
                            Een gepensioneerde vakman, betrouwbare hobbyklusser of student met twee rechterhanden. Wij hebben de man of vrouw die jouw klusjes komt fixen!
                        </p>
                    </div>
                    <div className="column is-offset-1">
                        <h5 className="is-size-5 has-text-primary">Ik heb klusjes</h5>
                        <ul>
                            <li>
                                <Link data-track-id="footer-kluslijst" to="/kluslijst">Maak je kluslijst</Link>
                            </li>
                        </ul>
                    </div>
                    <div className="column">
                        <h5 className="is-size-5 has-text-primary">Ik ben klusser</h5>
                        <ul>
                            <li>
                                <Link data-track-id="footer-aanmelden-als-klusser" to="/aanmeldenalsklusser">Meld je aan als klusser</Link>
                            </li>
                        </ul>
                    </div>
                    <div className="column">
                        <h5 className="is-size-5 has-text-primary">Meer informatie</h5>
                        <ul>
                            <li>
                                <a href="mailto:info@tjilp.eu">Contact</a>
                            </li>
                            <li>
                                <Link data-track-id="footer-privacy" to="/privacy">Privacy statement</Link>
                            </li>
                            <li>
                                <Link data-track-id="footer-voorwaarden" to="/voorwaarden">Algemene voorwaarden</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
)

export default Footer
