import React from "react"
import PropTypes from "prop-types"

import Navbar from "./Navbar"
import Footer from "./Footer"

class Layout extends React.Component{
  componentDidMount(){
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      'event' : 'optimize.activate'
    });
  }
  render(){
    return (
      <>
        <Navbar color={this.props.nav} />
          <main>
            {this.props.children}
          </main>
        <Footer />
      </>
    )
  }
}

Layout.propTypes = {
  children: PropTypes.node.isRequired,
}

export default Layout
