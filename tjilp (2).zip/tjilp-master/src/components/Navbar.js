import React from "react"
import {Link} from "gatsby"
import logo from "../images/logo.png"

class Navbar extends React.Component{
  state = {
    isOpenMobile:false
  }

  render(){
    return(
      <nav className={`navbar is-fixed-top ${this.props.color ? "is-white" : "is-primary"}`} role="navigation" aria-label="main navigation">
          <div className="container">
            <div className="navbar-brand">
              <Link className="navbar-item" to="/">
                <div className="logo-container">
                  <img src={logo} alt="tjilp-logo"/>
                  <span className="has-text-weight-bold">Tjilp</span>
                </div>
              </Link>
              <div role="button" className={`${this.state.isOpenMobile ? "is-active" : ""} navbar-burger burger`} onClick={() => this.setState({isOpenMobile:!this.state.isOpenMobile})} aria-label="menu" aria-expanded="false" data-target="mainNav">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
              </div>
            </div>

            <div id="mainNav" className={`${this.state.isOpenMobile ? "is-active" : ""} navbar-menu`}>

              <div className="navbar-end">

                <Link className="navbar-item" activeClassName="is-active" to="/">
                  <span className="navbar-item__text has-text-weight-bold">Ik heb klusjes</span>
                </Link>

                <Link className="navbar-item" activeClassName="is-active" to="/klusser/">
                  <span className="navbar-item__text has-text-weight-bold">Ik ben klusser</span>
                </Link>

                <div className="navbar-item">
                  <div className="divider"></div>
                </div>
                <div className="navbar-item ">
                  <div className="buttons">
                    <Link className="button is-secondary is-rounded is-small has-text-white" to="/kluslijst">
                      Mijn kluslijst
                    </Link>
                  </div>
                </div>
              </div>
            </div>
        </div>
        </nav>
    )
  }
}

export default Navbar
