import React from "react"
import Img from "gatsby-image"
import {graphql, useStaticQuery} from "gatsby"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faComment, faMapMarkerAlt, faPiggyBank } from '@fortawesome/free-solid-svg-icons'
import {Link} from 'gatsby'

const BecomeATjilperBanner = () => {

    const componentData = useStaticQuery(
        graphql`
            query {
                file(relativePath: {eq: "kluslijst-klusser.png"}) {
                    relativePath
                    childImageSharp {
                        fluid{
                            ...GatsbyImageSharpFluid
                        }
                    }
                  }
            }
        `
    )
    return(
        <>
        <div className="section has-background-primary">
            <div className="container has-text-white">
                <div className="become-tjilper-column columns is-vcentered">
                    <div className="column is-half">
                        <h1 className="is-size-1">Bijverdienen met kleine klusjes?</h1>
                        <p>Muur schilderen, gordijnrails ophangen, lampen vervangen. Jij draait er je hand niet voor om. Tjilp brengt jou in contact met mensen die meerdere klussen voor jou hebben opgespaard. Dat is lekker effectief bijverdienen.</p>
                        <Link id="become-tjilper-button" to="/aanmeldenalsklusser/" data-track-id="become-tjilper-button-banner" className="button is-rounded is-medium has-link is-success  has-text-weight-medium has-text-white">Meld je aan als klusser</Link>
                        <div className="columns is-hidden-touch">
                            <div className="column">
                                <h3 className="is-size-3"><FontAwesomeIcon icon={faComment}/></h3>
                                <p>Vertel ons wat jij goed kan</p>
                            </div>
                            <div className="column">
                            <h3 className="is-size-3"><FontAwesomeIcon icon={faMapMarkerAlt}/></h3>
                                <p>Kies uit kluslijstjes bij jou in de buurt</p>
                            </div>
                            <div className="column">
                            <h3 className="is-size-3"><FontAwesomeIcon icon={faPiggyBank}/></h3>
                                <p>Verdien bij met meerdere klusjes op 1 locatie</p>
                            </div>
                        </div>
                    </div>   
                    <div className="column is-offset-1 is-hidden-touch">
                        <Img fluid={componentData.file.childImageSharp.fluid} alt="kluslijst voorbeeld"/>
                    </div>       
                </div>
            </div>
        </div>
        </>
    )

}

export default BecomeATjilperBanner
