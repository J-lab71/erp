import React from "react"

class RangeSlider extends React.Component{
    state = {value:this.props.default || this.props.minValue}
    render(){
        const thumbWidth = 20;
        let position = ((this.state.value-this.props.minValue)/(this.props.maxValue-this.props.minValue)*100);
        let translate = (position/100*thumbWidth) - (thumbWidth/2); //because: [o    ] thumb falls within slider we need to translate the current value above the slider
        return(
            <div className="range-slider">
                <span className="range-slider__min-value">{this.props.minValue}</span>
                    <input className="range-slider__input" name={this.props.name} type="range" min={this.props.minValue} max={this.props.maxValue} value={this.state.value} onChange={e => this.setState({value:e.target.value})}/>
                <div className="range-slider__current-value" style={{left:`calc(${position}% - ${translate}px`}}><span>{this.props.before} {this.state.value} {this.props.after}</span></div>
                <span className="range-slider__max-value">{this.props.maxValue}</span>
            </div>
        )
    }
}

export default RangeSlider
