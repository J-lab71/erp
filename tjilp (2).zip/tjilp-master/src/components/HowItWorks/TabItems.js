import React from 'react';
import Img from "gatsby-image"
import {graphql, useStaticQuery} from "gatsby"
import {Link} from "gatsby"

const Ctas = () => (
    <>
    <Link to="/kluslijst" data-track-id="how-it-works-plaats-klus-aanbieder" className="button is-rounded is-success how-it-works__button has-text-white">Plaats je eerste klus</Link>
    <Link to="/klusser" data-track-id="how-it-works-aanmelden-als-klusser-aanbieder" className="button is-rounded is-primary is-outlined how-it-works__button">Meld je aan als klusser</Link>
    </>
);

const HandigeBuur = () => {
    const componentData = useStaticQuery(
        graphql`
            query {
                file(relativePath: {eq: "match.png"}) {
                    relativePath
                    childImageSharp {
                        fluid {
                            ...GatsbyImageSharpFluid
                        }
                    }
                  }
            }
        `
    )
    return(
        <div className="columns">
            <div className="column is-half">
                <p>
                    Een gepensioneerde vakman, betrouwbare hobbyklusser of student met twee rechterhanden. Wij hebben de man of vrouw die jou klusjes komt fixen!  
                </p>
                <Ctas />
            </div>
            <div className="column is-offset-1 is-one-third">
                <Img fluid={componentData.file.childImageSharp.fluid} alt="kluslijst voorbeeld"/>
            </div>
        </div>
    )    
}

const KlusjesBijhouden = () => (
    <div className="columns">
        <div className="column is-half">
            <p>
                Je kunt op ons platform al je kleine klusjes bijhouden. Ga naar je kluslijstje en voeg klusjes toe aan de lijst en wij brengen je in contact met een passende klussers.
            </p>
            <Ctas />
        </div>
    </div>
    
)

const Match = () => (
    <div className="columns">
        <div className="column is-half">
            <p>
                Er is een klusser die een aantal van jouw klusjes wilt oplossen. Top! Je maakt afspraken over de klusjes die hij of zij komt oplossen en jullie prikken natuurlijk een datum! Het uurtarief staat van te voren vast.
            </p>
            <Ctas />
        </div>
    </div>
    
)

const KlusjesGepiept = () => (
    <div className="columns">
        <div className="column is-half">
            <p>
                Eindelijk die loshangende trapleuning vastgezet en de goot van het tuinhuisje schoongemaakt, dat lucht op! Betaal de klusser veilig via ons platform en laat een review achter!
            </p>
            <Ctas />
        </div>
    </div>
    
)

const Betrouwbaar = () => (
    <div className="columns">
        <div className="column is-half">
            <p>
                Wij screenen onze klussers en daarnaast worden klussers beoordeeld door andere gebruikers! Je kunt er ook zelf voor kiezen om iemand af te wijzen tijdens de communicatie.
            </p>
            <Ctas />
        </div>
    </div>
    
)

const TransparantePrijzen = () => (
    <div className="columns">
        <div className="column is-half">
            <p>
                Wij rekenen een marge van 15%. De prijsindicaties die je ziet op het platform zijn inclusief deze marge.
            </p>
            <Ctas />
        </div>
    </div>
    
)

const tabItems = [
    {
        title:"Handige Buur",
        content:<HandigeBuur />,
    },
    {
        title:"Klusjes bijhouden",
        content:<KlusjesBijhouden />,
    },
    {
        title:"Er is een match!",
        content:<Match />,
    },
    {
        title:"Klusjes klaar",
        content:<KlusjesGepiept />,
    },
    {
        title:"Betrouwbaar",
        content:<Betrouwbaar />,
    },
    {
        title:"Transparante Prijzen",
        content:<TransparantePrijzen />
    }
];

export default tabItems;
