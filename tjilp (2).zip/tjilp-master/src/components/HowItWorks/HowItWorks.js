import React from 'react'


class HowItWorks extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            activeTab:0
        }
    }

    render(){    
        const tabItems=this.props.tabItems; //kan wellicht ook met children ipv props  
        const tabs = tabItems.map((tabItem, index) => 
            <li className={index === this.state.activeTab ? "tabbed__tab is-active" : "tabbed__tab has-text-weight-bold"} data-track-id={`how-it-works-${tabItem.title}`} key={index} onClick={() => (this.setState({activeTab:index}))}>           
                {tabItem.title}             
            </li>
        );

        const tabContent = tabItems.map((tabItem, index) =>
            <div key={index} className={index === this.state.activeTab ? "tab__tab-contents tab__tab-contents--is-active" : "tab__tab-contents"}>
                {tabItem.content}
            </div>
        );

        
        return(
            <div className="section how-it-works">
                <div className="container">
                    <h1 className="is-size-2 has-text-secondary has-text-centered">Zo werkt het</h1>
                    <ul className="tabbed">
                        {tabs}
                    </ul>
                    {tabContent} 
                </div>
            </div>
        )
    }
}

export default HowItWorks
