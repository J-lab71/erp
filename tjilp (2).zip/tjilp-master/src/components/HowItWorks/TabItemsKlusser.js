import React from 'react';
import Img from "gatsby-image"
import {graphql, useStaticQuery} from "gatsby"
import {Link} from "gatsby"

const Ctas = () => (
    <>
    <Link to="/aanmeldenalsklusser" data-track-id="how-it-works-aanmelden-als-klusser-klusser" className="button is-rounded is-secondary how-it-works__button has-text-white">Meld je aan als klusser</Link>
    <Link to="/kluslijst" data-track-id="how-it-works-plaats-klus-klusser" className="button is-rounded is-primary is-outlined how-it-works__button">Of plaats een klus</Link>
    </>
);

const SnelVerdient = () => {
    const componentData = useStaticQuery(
        graphql`
            query {
                file(relativePath: {eq: "match.png"}) {
                    relativePath
                    childImageSharp {
                        fluid {
                            ...GatsbyImageSharpFluid
                        }
                    }
                  }
            }
        `
    )
    return(
        <div className="columns">
            <div className="column is-half">
                <p>
                    Heb jij twee rechterhanden en wil je graag bijverdienen met het uitvoeren van kleine klusjes? Meld je aan als klusser en na een intake, houden wij jou op de hoogte van mensen in de buurt met klusjes die jij kan!
                </p>
                <Ctas />
            </div>
            <div className="column is-offset-1 is-one-third">
                <Img fluid={componentData.file.childImageSharp.fluid} alt="kluslijst voorbeeld"/>
            </div>
        </div>
    )    
}
const Match = () => (
    <div className="columns">
        <div className="column is-half">
            <p>
                Er is een mogelijke match! Bekijk de lijstjes die we aanbieden op basis van jouw vaardigheden. Zitten er dingen tussen die jij wilt oplossen? Laat het weten en we brengen jullie met elkaar in contact! Vervolgens spreek je samen af wanneer je langskomt en wie het materiaal koopt.
            </p>
            <Ctas />
        </div>
    </div>
    
)
const Btw = () => (
    <div className="columns">
        <div className="column is-half">
            <p>
                Je kunt de regels omtrent BTW vinden op deze pagina van de <a href="
https://www.belastingdienst.nl/wps/wcm/connect/nl/werk-en-inkomen/content/welke-bijverdiensten-moet-ik-aangeven
" target="_blank" rel="noopener noreferrer">belastingdienst</a>
            </p>
            <Ctas />
        </div>
    </div>
    
)

const tabItemsKlusser = [
    {
        title:"Aanmelden",
        content:<SnelVerdient />,
    },
    {
        title:"Er is een Match!",
        content:<Match />,
    },
    {
        title:"Hoe zit het met BTW?",
        content:<Btw />,
    },
];

export default tabItemsKlusser;
