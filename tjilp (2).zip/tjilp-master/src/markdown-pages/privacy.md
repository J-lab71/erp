---
page: "privacy"
---
### Privacy

Bold Guys B.V., handelende onder de naam Tjilp Platform via https://tjilp.eu, gevestigd aan Boslaan 15, 1405 BX te Bussum, hierna te noemen Tjilp, is verantwoordelijk voor de verwerking van persoonsgegevens zoals weergegeven in deze privacyverklaring.   

### Contactgegevens:
Het platform/website: https://tjilp.eu
Bold Guys B.V., handelende onder de naam Tjilp Platform, gevestigd aan de Boslaan 15, 1405 BX te Bussum
email: [info@tjilp.eu](mailto:info@tjilp.eu)
<br/><br/>

### Persoonsgegevens die wij verwerken
Tjilp verwerkt je persoonsgegevens doordat je gebruik maakt van onze diensten en/of omdat je deze gegevens zelf aan ons verstrekt. Hieronder vind je een overzicht van de persoonsgegevens die wij verwerken:
* Voor- en achternaam
* Adresgegevens
* E-mailadres
* IP-adres
* Overige persoonsgegevens die je actief verstrekt bijvoorbeeld door een profiel op deze website aan te maken, in correspondentie en telefonisch
* Gegevens over jouw activiteiten op onze website
* Internetbrowser en apparaat type
<br/><br/>

### Extra persoonsgegevens die wij verwerken voor aangemelde klussers
* De Klusser vragen wij een kopie van de ID kaart (of paspoort/rijbewijs) aan ons te doen toekomen. Dit verzoek doen we enkel om de identiteit te controleren van de betreffende persoon die de klus zal uitvoeren. Voor een veilige kopie en ook omdat wij niet alle persoonsgegevens nodig hebben voor de controle, vragen we u bij het doorsturen van de kopie het volgende in acht te nemen:

   * Zorg voor een heldere en duidelijke foto of scan van de ID kaart zonder storende achtergrond.
   * Er mag op de kopie geschreven worden, bijv. waarvoor deze gemaakt is.
   * De scan mag zowel in kleur als in zwart/wit gemaakt worden.
   * De pasfoto, het BSN en de nationaliteit mogen afgeschermd worden.
   * Uw identiteitsdocument mag niet verlopen zijn.
   * U kunt bijvoorbeeld ook de Kopie ID-app van de Rijksoverheid gebruiken om niet-noodzakelijke persoonsgegevens af te schermen. 

   We zijn verplicht zorgvuldig om te gaan met uw persoonsgegevens. Uw kopie identiteitsbewijs wordt na de controle vernietigd. 

<br/><br/>

### Bijzondere en/of gevoelige persoonsgegevens die wij verwerken
Onze website en/of dienst zijn bedoeld voor een algemeen publiek en niet voor kinderen. Onze website en/of dienst heeft niet de intentie gegevens te verzamelen over websitebezoekers die jonger zijn dan 16 jaar. Tenzij ze toestemming hebben van ouders of voogd. We kunnen echter niet controleren of een bezoeker van onze website jonger dan 16 is. Wij raden ouders dan ook aan betrokken te zijn bij de online activiteiten van hun kinderen, om zo te voorkomen dat er gegevens over kinderen verzameld worden zonder ouderlijke toestemming.

Wanneer je, je aanmeld op ons platform als klusser of aanbieder dien je 18 jaar of ouder te zijn of, indien jonger tot 16 jaar toestemming te hebben van je ouders/voogd omdat je een bemiddelingsovereenkomst aangaat met ons en een overeenkomst aangaat met een klusser/aanbieder op ons platform. Wij verwerken jouw persoonsgegevens om de bemiddelingsovereenkomst uit kunnen voeren. 

Als je er van overtuigd bent dat wij zonder die toestemming persoonlijke gegevens hebben verzameld over een minderjarige, neem dan contact met ons op via info@tjilp.eu, dan verwijderen wij deze informatie.

<br/><br/>

### Met welk doel en op basis van welke grondslag wij persoonsgegevens verwerken
Tjilp verwerkt jouw persoonsgegevens voor de volgende doelen:
* Voor het aangaan en uitvoeren van onze bemiddelingsovereenkomst met jou en zodat jij overeenkomsten kunt sluiten met klusser/aanbieder op ons platform; 
* Om je de gelegenheid te geven om content op ons platform te plaatsen;
* Je te kunnen bellen of e-mailen indien dit nodig is om onze dienstverlening uit te kunnen voeren
* Je te informeren over wijzigingen van onze diensten
* Om de diensten die wij leveren te verbeteren
* Tjilp analyseert jouw gedrag op de website om daarmee de website te verbeteren en het aanbod van producten en diensten af te stemmen op jouw voorkeuren.
* Voor aangemelde klussers: Om jouw identiteit te controleren

Wij verzamelen en gebruiken geen informatie voor andere doeleinden dan de doeleinden die hierboven worden beschreven tenzij we van tevoren je toestemming hiervoor hebben verkregen of omdat wij dit op grond van de wet mogen doen.
<br/><br/>

### Grondslagen
De wet bevat een opsomming van grondslagen die de verwerking van je persoonsgegevens rechtvaardigen. Wij beroepen ons op drie van deze grondslagen. Wij lichten hieronder toe welke dit zijn:

1. **Uitvoering van de overeenkomst**. Wij gebruiken jouw persoonsgegevens om een bemiddelingsovereenkomst met jou te kunnen sluiten en uit te voeren, op het moment dat je, je aanmeldt op ons platform. 
2. **Gerechtvaardigd belang**. De verwerking van je persoonsgegevens is nodig voor de uitvoering van onze diensten en het behartigen van de eigen redelijke en zakelijke belangen. Voorbeelden van de zakelijke belangen zijn: De informatiebeveiliging van onze site en mobiele toepassingen bewaken en verbeteren en het verdedigen van de eigen belangen in een buitengerechtelijke of juridische procedure. 
3. **Toestemming**. Wij mogen met je toestemming je persoonsgegevens gebruiken voor bepaalde marketingactiviteiten, bijv.:
    * Marketing aan je aanbieden via e-mail in de vorm van bijvoorbeeld een nieuwsbrief
    * Marketing van derden aan je aanbieden.
    * Advertenties van derden aanpassen die je mogelijk op websites van derden ziet.

### Geautomatiseerde besluitvorming
Wij maken geen gebruik van profilering en/of andere geautomatiseerde besluitvorming.

<br/><br/>

### Hoe lang we persoonsgegevens bewaren
Tjilp bewaart je persoonsgegevens niet langer dan strikt nodig is om de doelen te realiseren waarvoor je gegevens worden verzameld. Wij hanteren de volgende bewaartermijnen voor de volgende (categorieën) van persoonsgegevens: 

* IP adres bij bezoeken (30 dagen door onze hosting-partij <a href="https://netlify.com/" target="_blank" rel="noopener noreferrer">Netlify</a>)
* IP adres bij insturen van een formulier ( maximaal 1 jaar )
* Gegevens bij het insturen van jouw kluslijst zoals de 4 cijfers van je postcode en e-mail adres (zolang je gebruik maakt van onze diensten)
* Gegevens bij het aanmelden als klusser zoals naam, e-mail, lijst met klusjes die je kunt uitvoeren en de 4 cijfers van je postcode (zolang je gebruik maakt van onze diensten)
* Netlify( onze hosting) werkt met Akismet om spam bij het versturen van alle formulieren op onze website tegen te gaan, meer informatie en de bewaartermijnen van Akismet vind je <a href="https://akismet.com/privacy/" target="_blank" rel="noopener noreferrer">hier</a>

Op het moment dat een bewaartermijn verstrijkt, zullen je persoonsgegevens worden verwijderd of de identificerende kenmerken worden verwijderd.
<br/><br/>


### Delen van persoonsgegevens met derden
Tjilp deelt jouw persoonsgegevens met verschillende derden als dit noodzakelijk is voor het uitvoeren van de overeenkomst en om te voldoen aan een eventuele wettelijke verplichting. 
Je persoonsgegevens kunnen worden doorgegeven aan locaties buiten de Europese Economische Ruimte. Indien een dergelijke doorgifte van je gegevens plaatsvindt naar een land buiten de Europese Economische Ruimte zullen wij ons ervan vergewissen dat een afdoende beschermingsniveau wordt gewaarborgd, dat de nodige maatregelen en relevante controleprocedures worden gehanteerd om de vertrouwelijkheid en beveiliging van jouw gegevens te beschermen, en dat deze doorgifte in overeenstemming is met de geldende wetgeving op het gebied van gegevensbescherming. Om het beschermingsniveau zowel binnen als buiten de EU, te waarborgen hebben wij om deze reden verwerkers-overeenkomsten afgesloten met verwerkers van je persoonsgegevens.Ook maken wij gebruik van speciale contracten van de Europese Commissie voor het delen van uw persoonlijke gegevens buiten de EU. Deze verwerkers zijn bijvoorbeeld onze hostingpartij. Tjilp blijft verantwoordelijk voor deze verwerkingen. 

<br/><br/>

### Bedrijven buiten de EU

**Netlify**   
Voor het hosten van deze website maken wij gebruik van Netlify.com(Amerikaans) Wij hebben met hun een verwerkersovereenkomst meer over hoe netlify de GDPR toepast vind je hier. Netlify houd access logs bij met daarin bijvoorbeeld errors en bewaard IP-adressen 30 dagen. De privacy policy van Netlify vind je <a href="https://netlify.com/gdpr/" target="_blank" rel="noopener noreferrer">hier</a>.
<br/>
<br/>

**Netlify forms**  
We gebruiken Netlify forms om formulieren op te slaan. De data van het formulier wordt opgeslagen op de servers van Netlify samen met een IP-adres en een datum en tijd. Het IP adres helpt met het herkennen van Spam. Wil je geen formulier versturen dan kun je ons altijd een e-mail sturen met dezelfde informatie als in de formulieren op onze site.   
<br/>

**Mailchimp**  
We gebruiken Mailchimp om jouw te mailen nadat je je aanmeld als klusser of wanneer je bijvoorbeeld een kluslijst verstuurd. Als je je hebt aangemeld voor een nieuwsbrief gebruiken we Mailchimp om deze nieuwsbrief naar jou te versturen. Je vind de privacy policy van Mailchimp hier <a href="https://mailchimp.com/legal/privacy/" target="_blank" rel="noopener noreferrer">hier</a>
<br/>
<br/>

**Akismet** 
Netlify werkt met de Akismet API om verstuurde formulieren te controleren op spam. De meest up to date versie van de manier waarop Akismet omgaat met privacy vind je <a href="https://akismet.com/privacy/" target="_blank" rel="noopener noreferrer">hier</a>. Wil je geen formulier versturen dan kun je ons altijd een e-mail sturen met dezelfde informatie als in de formulieren op onze site.
<br/><br/>

### Cookies, of vergelijkbare technieken, die wij gebruiken
tjilp.eu gebruikt alleen technische en functionele cookies. En analytische cookies(Google analytics met geanonimiseerde IP adressen) die geen inbreuk maken op je privacy. Een cookie is een klein tekstbestand dat bij het eerste bezoek aan deze website wordt opgeslagen op jouw computer, tablet of smartphone. De cookies die wij gebruiken zijn noodzakelijk voor de technische werking van de website en jouw gebruiksgemak. Ze zorgen ervoor dat de website naar behoren werkt en onthouden bijvoorbeeld jouw voorkeursinstellingen. Ook kunnen wij hiermee onze website optimaliseren. Je kunt je afmelden voor cookies door je internetbrowser zo in te stellen dat deze geen cookies meer opslaat. Daarnaast kun je ook alle informatie die eerder is opgeslagen via de instellingen van je browser verwijderen.
<br/><br/>

### Gegevens inzien, aanpassen of verwijderen
Je hebt het recht om je persoonsgegevens in te zien, te corrigeren of te verwijderen. Daarnaast heb je het recht om je eventuele toestemming voor de gegevensverwerking in te trekken of bezwaar te maken tegen de verwerking van jouw persoonsgegevens door tjilp.eu en heb je het recht op gegevensoverdraagbaarheid. Dat betekent dat je bij ons een verzoek kan indienen om de persoonsgegevens die wij van jou beschikken in een computerbestand naar jou of een ander, door jou genoemde organisatie, te sturen. Ook heb je het recht op beperking (dit betekent dat de verwerking van uw persoonsgegevens tijdelijk wordt bevroren totdat een bezwaar of geschil is opgelost). Verder heb je nog recht om vergeten te worden en het recht tot rectificatie.
Je kunt een verzoek tot inzage, correctie, verwijdering, beperking, gegevensoverdraging, recht om vergeten te worden, recht tot rectificatie van je persoonsgegevens of verzoek tot intrekking van je toestemming of bezwaar op de verwerking van jouw persoonsgegevens sturen naar info@tjilp.eu.  Om er zeker van te zijn dat het verzoek tot inzage door jou is gedaan, vragen wij jou een kopie van je identiteitsbewijs met het verzoek mee te sturen. Maak in deze kopie je pasfoto, MRZ (machine readable zone, de strook met nummers onderaan het paspoort), paspoortnummer en Burgerservicenummer (BSN) zwart. Dit ter bescherming van je privacy. We reageren zo snel mogelijk, maar binnen vier weken, op jouw verzoek .

Tjilp wil je er tevens op wijzen dat je de mogelijkheid hebt om een klacht in te dienen bij de nationale toezichthouder, de Autoriteit Persoonsgegevens. Dat kan via de volgende link: https://autoriteitpersoonsgegevens.nl/nl/contact-met-de-autoriteit-persoonsgegevens/tip-ons
<br/><br/>

### Hoe wij persoonsgegevens beveiligen
tjilp.eu neemt de bescherming van jouw gegevens serieus en neemt passende maatregelen om misbruik, verlies, onbevoegde toegang, ongewenste openbaarmaking en ongeoorloofde wijziging tegen te gaan. Zo zorgen wij bijvoorbeeld dat alleen de noodzakelijke personen toegang hebben tot uw gegevens en dat de toegang tot de gegevens afgeschermd is. 

Als jij het idee hebt dat jouw gegevens toch niet goed beveiligd zijn of er aanwijzingen zijn van misbruik, neem dan contact op met onze klantenservice of via <a href="mailto:info@tjilp.eu">info@tjilp.eu</a>


